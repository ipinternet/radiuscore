<?php declare(strict_types = 1);

// odsl-C:/xampp/htdocs/radiuscore/vendor/composer/../symfony/polyfill-intl-normalizer/Resources/stubs
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1-enums',
   'data' => 
  array (
    'C:\\xampp\\htdocs\\radiuscore\\vendor\\symfony\\polyfill-intl-normalizer\\Resources\\stubs\\Normalizer.php' => 
    array (
      0 => 'f98e9fe75a0e2008e4e16ca369aa132a45408d4034b668e4afea9fcddca69964',
      1 => 
      array (
        0 => 'normalizer',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
  ),
));