<?php declare(strict_types = 1);

// osfsl-C:/xampp/htdocs/radiuscore/vendor/composer/../laravel/framework/src/Illuminate/Notifications/HasDatabaseNotifications.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Illuminate\Notifications\HasDatabaseNotifications
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-a7a163aa1f98a0ae4cd2135905b6852e29a850beb4296aa72c44c37d22832135-8.4-6.70.0.3',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'filename' => 'C:/xampp/htdocs/radiuscore/vendor/composer/../laravel/framework/src/Illuminate/Notifications/HasDatabaseNotifications.php',
      ),
    ),
    'namespace' => 'Illuminate\\Notifications',
    'name' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
    'shortName' => 'HasDatabaseNotifications',
    'isInterface' => false,
    'isTrait' => true,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 5,
    'endLine' => 36,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'notifications' => 
      array (
        'name' => 'notifications',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the entity\'s notifications.
 *
 * @return \\Illuminate\\Database\\Eloquent\\Relations\\MorphMany<DatabaseNotification, $this>
 */',
        'startLine' => 12,
        'endLine' => 15,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Illuminate\\Notifications',
        'declaringClassName' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'implementingClassName' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'currentClassName' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'aliasName' => NULL,
      ),
      'readNotifications' => 
      array (
        'name' => 'readNotifications',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the entity\'s read notifications.
 *
 * @return \\Illuminate\\Database\\Eloquent\\Relations\\MorphMany<DatabaseNotification, $this>
 */',
        'startLine' => 22,
        'endLine' => 25,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Illuminate\\Notifications',
        'declaringClassName' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'implementingClassName' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'currentClassName' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'aliasName' => NULL,
      ),
      'unreadNotifications' => 
      array (
        'name' => 'unreadNotifications',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the entity\'s unread notifications.
 *
 * @return \\Illuminate\\Database\\Eloquent\\Relations\\MorphMany<DatabaseNotification, $this>
 */',
        'startLine' => 32,
        'endLine' => 35,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Illuminate\\Notifications',
        'declaringClassName' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'implementingClassName' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'currentClassName' => 'Illuminate\\Notifications\\HasDatabaseNotifications',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));